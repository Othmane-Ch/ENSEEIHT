module PasseCodeRatToTam : Passe.Passe with type t1 = Ast.AstPlacement.programme and type t2 = string =
struct
  open Type
  open Tds
  open Ast
  open AstType
  open Code

  type t1 = Ast.AstPlacement.programme
  type t2 = string



(* analyse_tds_typenomme : AstType.Typedefini -> AstCodeRatToTam.Typedefini  * typ *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre : le type npmmée à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le type nommée
en une TypeNomme de type AstCodeRatToTam.TypeNomme *)
(* Erreur si l'identifiant est Déclaré deux fois *)
let analyse_code_typenomme  td =
  match td with
   | AstType.TypeNomme ia -> 
    begin 
      match info_ast_to_info ia with 
        | InfoType(_,t) -> "\n"^"LOAD ("^(string_of_int(getTaille t))^") "
        |    _      ->   failwith ""
    end 

  let rec analyse_code_affectable a = 
    match a with 
    | AstType.Ident ia -> 
      begin
        match info_ast_to_info ia with
          | InfoVar(_, t, d, reg) -> ("\n"^"LOAD ("^(string_of_int(getTaille t))^") "^(string_of_int d)^"["^reg^"]\n",t)
          | InfoConst(_,v) -> ("\n"^"LOADL "^(string_of_int v)^"\n", Int)
          | _ -> failwith ""
      end
    | AstType.Deref v ->  
        let (na,t) = analyse_code_affectable v in   
        ("\n"^na^"LOADI ("^(string_of_int(getTaille t))^")\n",t)
    | AstType.Acces (a,ia) -> 
      let (na,_) = analyse_code_affectable a in
      begin
          match info_ast_to_info ia with
            | InfoVar(_, t, d, reg) -> ("\n"^na^"\n"^"LOAD ("^(string_of_int(getTaille t))^") "^(string_of_int d)^"["^reg^"]\n",t)
            | _ -> failwith ""
      end
(* analyse_code_expression : expression -> string *)
(* Produit le code correspondant à l'instruction. L'execution de ce code 
   laissera en sommet de pile le résultat de l'évaluation de cette expression *)
let rec analyse_code_expression  e =
  match e with
    | AppelFonction(ia,le) -> let InfoFun(n,_,_) = info_ast_to_info ia in
    "\n"^
    (List.fold_left (fun e1 e2 -> e1 ^ analyse_code_expression e2) "" le)^"\nCALL (LB) "^n^"\n"
    | Affectable a -> let (na,_) = analyse_code_affectable a in
    na 
    | Booleen b -> if b then "LOADL 1\n" else "LOADL 0\n"
    | Entier m -> "LOADL "^(string_of_int m)^"\n"
    | Unaire(unaire,exp) -> 
    "\n"^
      begin
        match unaire with
            | Numerateur   -> (analyse_code_expression exp)^"\nPOP (0) 1\n"
            | Denominateur -> (analyse_code_expression exp)^"\nPOP (1) 1\n"
      end
    | Binaire(binaire,e1,e2) -> let str1 = analyse_code_expression e1 in
    let str2 = analyse_code_expression e2 in
    "\n"^
    begin
      match binaire with
       | Fraction   -> str1^str2^"\n"
       | PlusInt    -> str1^str2^"SUBR IAdd\n"
       | PlusRat    -> str1^str2^"CALL (SB) RAdd\n"
       | MultInt    -> str1^str2^"SUBR IMul\n"
       | MultRat    -> str1^str2^"CALL (SB) RMul\n"
       | EquInt     -> str1^str2^"SUBR IEq\n"
       | EquBool    -> str1^str2^"SUBR IEq\n"
       | Inf     -> str1^str2^"SUBR ILss\n"
    end
    | Null -> ""  
    | New t -> "LOADL "^(string_of_int(getTaille t))^"\n"^"SUBR Malloc \n" 
    | Adresse ia -> 
      begin
        match info_ast_to_info ia with
          | InfoVar(_, t, d, reg) -> "\n"^"LOAD ("^(string_of_int(getTaille t))^") "^(string_of_int d)^"["^reg^"]\n"
          | _ -> failwith "Error"
      end
    |ChampValeur le ->
      let nle = List.map analyse_code_expression le in 
      String.concat "" nle
 


(* analyse_code_instruction : instruction -> string *)
let rec analyse_code_instruction tr tp i =
  match i with 
    | Declaration(ia,e) -> let InfoVar(_,t,d,reg) = info_ast_to_info ia in
    let str = analyse_code_expression e in
    "\n"^
    "PUSH "^(string_of_int (getTaille t))^"\n"^str^"\nSTORE ("^(string_of_int (getTaille t))^") "^(string_of_int d)^"["^reg^"]\n"
    | Affectation(a,e) -> 
    let str = analyse_code_expression e in
    begin 
      match a with
        | AstType.Ident ia ->
          begin
            match info_ast_to_info ia with 
              | InfoVar(_,t,d,reg) ->  "\n"^str^"\nSTORE ("^(string_of_int (getTaille t))^") "^(string_of_int d)^"["^reg^"]\n"
              | _ -> failwith "Error"
          end
        | AstType.Deref _ -> let (na,ta) = analyse_code_affectable a in
                              "\n"^str^na^"\nSTOREI ("^(string_of_int (getTaille ta))^") "^"\n"
        | AstType.Acces (a,ia) -> 
          let (na,_) = analyse_code_affectable a in
          begin
              match info_ast_to_info ia with
                | InfoVar(_, t, d, reg) -> "\n"^str^"\n"^na^"\nSTORE ("^(string_of_int (getTaille t))^") "^(string_of_int d)^"["^reg^"]\n"
                | _ -> failwith ""
          end 
    end
    | AssignationAddition(a,e) ->
    let str = analyse_code_expression e in
    "\n"^str^
    begin 
      match a with
       | AstType.Ident ia ->
        begin
          match info_ast_to_info ia with 
            | InfoVar(_,t,d,reg) ->  if (est_compatible Int t) then "SUBR IAdd\n"^"\nSTORE ("^(string_of_int (getTaille t))^") "^(string_of_int d)^"["^reg^"]\n" 
            else "CALL (SB) RAdd\n"^"\nSTORE ("^(string_of_int (getTaille t))^") "^(string_of_int d)^"["^reg^"]\n"
            | _ -> failwith "Error"
        end
        | AstType.Deref _ -> let (na,ta) = analyse_code_affectable a in
          if (est_compatible Int ta) then "SUBR IAdd\n"^na^"\nSTOREI ("^(string_of_int (getTaille ta))^") "^"\n"
          else "CALL (SB) RAdd\n"^na^"\nSTOREI ("^(string_of_int (getTaille ta))^") "^"\n"
    end
    | AffichageInt e -> (analyse_code_expression e )^"SUBR IOut\n"
    | AffichageRat e -> (analyse_code_expression e )^"CALL (ST) ROut\n"
    | AffichageBool e -> (analyse_code_expression e )^"SUBR BOut\n"
    | Conditionnelle(e,bt,be) -> let etiq = getEtiquette() in
    let etiq_else = etiq ^ "else " in
    let etiq_end_if = etiq ^"end_if" in
    let ne = analyse_code_expression e in
    let nbt,pop_taille_if = analyse_code_bloc tr tp bt in
    let nbe,pop_taille_else = analyse_code_bloc tr tp be in
    "\n"^ ne ^ "\n" ^
    "JUMPIF (0) "^etiq_else^"\n"^nbt^"\nPOP (0) "^(string_of_int pop_taille_if)^"\n"^
    "JUMP "^etiq_end_if^"\n"^etiq_else^"\n"^nbe^"\nPOP (0) "^(string_of_int pop_taille_else)^"\n"^
    etiq_end_if^"\n"
    | TantQue(e,b) -> let etiq_debut =  getEtiquette() in
    let etiq_fin = getEtiquette() in
    let ne = analyse_code_expression e in
    let nb,pop_taille_tantque = analyse_code_bloc tr tp b in
    "\n"^
    etiq_debut^"\n"^ne^"JUMPIF (0) "^etiq_fin^"\n"^nb^"\nPOP (0)"^(string_of_int pop_taille_tantque)^"\n"^
    "JUMP "^etiq_debut^"\n"^etiq_fin^"\n"
    | Typedefinition ia ->   
    begin 
      match info_ast_to_info ia with 
        | InfoType(_,t) -> "\n"^"LOAD ("^(string_of_int(getTaille t))^") "
        |    _      ->   failwith ""
    end
    | Retour e -> let ne = analyse_code_expression e in
    ne^"\n"^"RETURN ("^(string_of_int tr)^") "^(string_of_int tp) ^"\n"
    | Empty -> "" 

and analyse_code_bloc tr tp li = let taille = List.fold_right (fun t tq -> (taille_variables_declarees t) + tq) li 0 in
    let _ = "\n\nPOP (0) "^(string_of_int taille)^"\n" in
    (analyse_code_li tr tp li), taille

(* une liste d'instructions est un bloc donc on ignore la taille des variables locales *)
and analyse_code_li tr tp li = String.concat "" (List.map (analyse_code_instruction tr tp) li)
(* analyse_code_fonction : AstPlacement.fonction -> string *)
let analyse_code_fonction (AstPlacement.Fonction(ia,lp,li)) =
  match info_ast_to_info ia with
     | InfoFun(n,t,ltp) -> 
      let tr = getTaille t in
      let tp = List.fold_right (fun t tq -> (getTaille t) + tq) ltp 0 in
      let nli,pop_bloc =  analyse_code_bloc tr tp li in
      n^"\n"^nli^"\nPOP ("^(string_of_int (tr))^")"^(string_of_int pop_bloc)^
      "\nRETURN ("^(string_of_int (tr))^")"^(string_of_int tp)^"\n"
     | _ -> failwith "Error"

let analyser (AstPlacement.Programme(lf,prog)) =
  let nlf = List.map analyse_code_fonction lf in
  let nprog,_ = analyse_code_bloc 0 0 prog in
  let rec code_fonction l = 
    match l with
       | []  -> ""  
       | t::q ->  t^"\n"^(code_fonction q)
  in 
  getEntete() ^
  (code_fonction nlf) ^ "\n" ^
  "main\n" ^
  nprog ^"\n"^
  "HALT\n"

end 



