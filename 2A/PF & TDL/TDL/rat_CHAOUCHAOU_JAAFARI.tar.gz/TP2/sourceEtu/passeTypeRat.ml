module PasseTypeRat : Passe.Passe with type t1 = Ast.AstTds.programme and type t2 = Ast.AstType.programme =
struct
  open Type
  open Tds
  open Exceptions
  open Ast
  open AstType

  type t1 = Ast.AstTds.programme
  type t2 = Ast.AstType.programme




(* analyse_type_typenomme : AstTDS.Typedefini -> AstType.Typedefini  * typ *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre : le type nommée à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le type nommée
en une TypeNomme de type AstTds.TypeNomme *)
(* Erreur si l'identifiant est Déclaré deux fois *)
let analyse_type_typenomme  td =
  match td with
   | AstTds.TypeNomme (ia,t) -> modifier_type_info t ia;
                    (TypeNomme ia , t)

(* analyse_type_affectable : AstTds.affectable   -> AstType.affectable * typ *)
(* Paramètre a : l'affectable à analyser *)
(* Vérifie la bonne utilisation des affectables et tranforme l'affectable
en une affectable de type AstType.instruction *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_type_affectable  a  =
  match a with 
  | AstTds.Ident ia ->
    begin
      match info_ast_to_info ia with
            | InfoConst _ -> (Ident(ia),Int)
            | InfoVar(_,t,_,_) -> (Ident(ia),t)
            | _ -> failwith ("Erreur")
    end
  | AstTds.Deref v -> 
    begin
      match (analyse_type_affectable v) with
            | (na,Pointeur ta) -> (Deref na,ta)
            | _ -> failwith ("Erreur")
    end
    | AstTds.Acces (a,ia) ->
    let (na,Enregistrement l) = analyse_type_affectable a in
    let lt = List.map fst l in
    let ln = List.map snd l in
    let l1 = List.combine ln lt in
      begin
        match info_ast_to_info ia with
            | InfoVar(n,_,_,_) ->  begin
                                    try (let tr = List.assoc n l1 in modifier_type_info tr  ia;(Acces (na,ia),tr)) with
                                        Not_found -> raise (IdentifiantNonDeclare(n)) 
                                  end
            | _ -> raise (NotFoundException)
      end
(* analyse_type_expression : AstTds.expression -> (AstType.expression,tr) *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre e : l'expression à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'expression
en une expression de type AstType.expression *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_type_expression e =
  match e with
    |AstTds.AppelFonction(ia,le) ->
        let InfoFun(_,tr,tparam) = info_ast_to_info ia  in
        let nlet = List.map analyse_type_expression le in
        let nle = List.map fst nlet  in
        let nlt = List.map snd nlet in
        if(tparam = nlt) then 
          (AppelFonction(ia,nle),tr) 
        else 
          raise (TypesParametresInattendus (tparam,nlt))

    |AstTds.Booleen b -> (Booleen(b),Bool)
    |AstTds.Entier n -> (Entier(n),Int)
    |AstTds.Unaire (u,exp) -> let (expType,te) = analyse_type_expression exp in
    if (te = Rat) then
        begin
          match u with 
            | Numerateur -> (AstType.Unaire(Numerateur,expType),Int)
            | Denominateur -> (AstType.Unaire(Denominateur,expType),Int)
        end
     else raise (TypeInattendu (te,Rat))

    |AstTds.Binaire(binaire,exp1,exp2) -> let (ne1,t1) = analyse_type_expression exp1 in
    let (ne2,t2) = analyse_type_expression exp2 in
    begin
      match t1,binaire,t2 with
       | Int,Fraction,Int   -> (Binaire(Fraction,ne1,ne2),Rat)
       | Int,Plus,Int -> (Binaire(PlusInt,ne1,ne2),Int)
       | Rat,Plus,Rat -> (Binaire(PlusRat,ne1,ne2),Rat)
       | Int,Mult,Int  ->  (Binaire(MultInt,ne1,ne2),Int)
       | Rat,Mult,Rat -> (Binaire(MultRat,ne1,ne2),Rat)
       | Int,Equ,Int ->  (Binaire(EquInt,ne1,ne2),Bool)
       | Bool,Equ,Bool -> (Binaire(EquBool,ne1,ne2),Bool)
       | Int,Inf,Int -> (Binaire(Inf,ne1,ne2),Bool)
       | _ -> raise(TypeBinaireInattendu(binaire,t1,t2))   
    end
  | AstTds.Affectable a -> 
    let (na, ta) = analyse_type_affectable a in
    (Affectable na,ta)
  | AstTds.Null -> (Null,Pointeur Undefined)
  | AstTds.New t -> (New (t),Pointeur(t))
  | AstTds.Adresse ia -> 
    begin
      match info_ast_to_info ia with
      | InfoVar(_,t,_,_) -> (Adresse ia,Pointeur t)
      | _ -> failwith "Erreur"
    end
  | AstTds.ChampValeur le -> let l = List.map analyse_type_expression le in 
    let nle = List.map fst l in 
    let nlt = List.map snd l in
    let dp = List.map (fun t -> (t,"")) nlt in
    (ChampValeur nle, Enregistrement dp)
      

(* analyse_type_instruction : AstTds.instruction -> type -> AstType.instruction *)
(* Paramètre tf : type final *)
(* Paramètre i : l'instruction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'instruction
en une instruction de type AstType.instruction *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_type_instruction tf i = 
  match i with
   | AstTds.Empty -> Empty
   | AstTds.Declaration(t,ia,e) -> modifier_type_info t  ia;
   let (ne,te) = analyse_type_expression e in 
   if est_compatible t te then Declaration(ia,ne)
   else raise (TypeInattendu (te,t))
   | AstTds.Affectation(a,e) ->
   let (na,ta) = analyse_type_affectable a in
   let (ne,te) = analyse_type_expression e in
   if (est_compatible ta te) then  Affectation(na,ne)
   else raise (TypeInattendu(te,ta))
   | AstTds.Affichage e -> let (ne,te) = analyse_type_expression e in
   begin
    match te with
      | Int -> AffichageInt ne
      | Rat -> AffichageRat ne
      | Bool -> AffichageBool ne
      | _ -> failwith ("Type not found")
   end
   | AstTds.AssignationAddition(a,e) ->  
   let (na,ta) = analyse_type_affectable a in
   let (ne,te) = analyse_type_expression e in
   if (est_compatible ta te) then
      if ((est_compatible Int te) || (est_compatible Rat te) ) then
        AssignationAddition(na,ne)
      else raise (TypeBinaireInattendu(Plus,ta,te)) 
   else raise (TypeInattendu(te,ta))

   | AstTds.Conditionnelle(e,bt,be) -> let (ne,te) = analyse_type_expression e in
   if (est_compatible te Bool) 
   then let nbt = analyse_type_bloc tf bt in 
        let nbe = analyse_type_bloc tf be in
        Conditionnelle(ne,nbt,nbe)  

   else  raise (TypeInattendu (te,Bool))
      
   | AstTds.TantQue(e,bt) -> let (ne,te) = analyse_type_expression e in
   if (est_compatible te Bool) 
   then let nbt = analyse_type_bloc tf bt in 
        TantQue(ne,nbt)
   else raise (TypeInattendu (te,Bool))

   | AstTds.Typedefinition(ia,t) -> modifier_type_info t ia;
                      Typedefinition ia 
   
   | AstTds.Retour e -> let (ne,te) = analyse_type_expression e in
    begin
      match tf with
        | None -> raise (RetourDansMain)
        | Some t -> 
        if est_compatible t te then Retour ne 
        else raise (TypeInattendu (te,t))
    end
    
    


(* analyse_tds_bloc : AstTds.bloc -> AstType.bloc *)
(* Paramètre tf  : type option finale *)
(* Paramètre li : liste d'instructions à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le bloc
en un bloc de type AstType.bloc *)
(* Erreur si mauvaise utilisation des identifiants *)
and analyse_type_bloc tf li = List.map (analyse_type_instruction tf) li





(* analyse_type_fonction : AstTds.fonction -> AstType.fonction *)
(* Paramètre : la fonction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme la fonction
en une fonction de type AstType.fonction *)
(* Erreur si mauvaise utilisation des identifiants *)

let analyse_type_fonction (AstTds.Fonction(t,n,lp,li))= 
    List.iter (fun (tp,p) -> modifier_type_info tp p) lp; 
    modifier_type_fonction_info t (List.map fst lp) n;
    let liste_param = List.map snd lp in
    let nli = analyse_type_bloc (Some t) li in
    Fonction(n,liste_param,nli)



       

(* analyser : AstTds.ast -> AstType.ast *)
(* Paramètre : le programme à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le programme
en un programme de type AstType.ast *)
(* Erreur si mauvaise utilisation des identifiants  *)
let analyser (AstTds.Programme(ltd,fonctions,prog)) =
      let nlf = List.map analyse_type_fonction fonctions in
      let nb = analyse_type_bloc None prog in
      let (nltd,_) = List.split (List.map (analyse_type_typenomme ) ltd) in 
      Programme(nltd,nlf,nb)

end