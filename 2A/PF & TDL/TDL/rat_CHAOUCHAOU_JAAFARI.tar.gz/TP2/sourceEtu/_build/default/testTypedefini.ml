(*
open Compilateur
open Exceptions




let%test_unit "testTypedefini1" = 
 try
  let _ = compiler "../../fichiersRat/src-rat-typedefini-test/testTypedefini1.rat" in ()
  with
  | IdentifiantNonDeclare("y") -> () 
 (* 
let%test_unit "testEnregistrement2" = 
  try
    let _ = compiler "../../fichiersRat/src-rat-typedefini-test/testTypedefini2.rat" in ()
  with
  | TypeInattendu(Enregistrement [(Bool,"");(Int,"")] , Enregistrement [(Int,"x");(Int,"y")])  -> () 
*)
let%test_unit "testTypedefini3" = 
  let _ = compiler "../../fichiersRat/src-rat-typedefini-test/testTypedefini3.rat" in ()

let%test_unit "testTypedefini4" = 
  let _ = compiler "../../fichiersRat/src-rat-typedefini-test/testTypedefini4.rat" in ()

let%test_unit "testTypedefini5" = 
  let _ = compiler "../../fichiersRat/src-rat-typedefini-test/testTypedefini5.rat" in ()


  *)