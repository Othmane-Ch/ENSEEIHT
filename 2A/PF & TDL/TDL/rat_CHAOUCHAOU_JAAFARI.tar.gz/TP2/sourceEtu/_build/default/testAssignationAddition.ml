open Compilateur
open Exceptions




let%test_unit "testAssignationAddition1" = 
  let _ = compiler "../../fichiersRat/src-rat-AssignationAddition-test/testAssignationAddition1.rat" in ()

let%test_unit "testAssignationAddition2" = 
  try 
    let _ = compiler "../../fichiersRat/src-rat-AssignationAddition-test/testAssignationAddition2.rat" in ()
  with
  | TypeInattendu(Int, _) -> () 
let%test_unit "testAssignationAddition3" = 
  try 
   let _ = compiler "../../fichiersRat/src-rat-AssignationAddition-test/testAssignationAddition3.rat" in ()
  with
  | TypeBinaireInattendu(Plus,Bool,Bool) -> () 


let%test_unit "testAssignationAddition4" = 
  try 
    let _ = compiler "../../fichiersRat/src-rat-AssignationAddition-test/testAssignationAddition4.rat" in ()
  with
  | TypeInattendu(Rat, Int) -> () 