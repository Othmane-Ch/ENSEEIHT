type typ = Bool | Int | Rat | Undefined | Pointeur of typ | TypeNomme of string * typ | Enregistrement of (typ * string) list 

let rec string_of_type t = 
  match t with
  | Bool ->  "Bool"
  | Int  ->  "Int"
  | Rat  ->  "Rat"
  | Undefined -> "Undefined"
  | Pointeur t -> "Pointeur " ^ (string_of_type t)
  | TypeNomme (s,_) -> s 
  | Enregistrement l -> let lt = List.map fst l in 
                        "Enregistrement " ^  (String.concat "," (List.map string_of_type lt) )

let rec est_compatible t1 t2 =
  match t1, t2 with
  | Bool, Bool -> true
  | Int, Int -> true
  | Rat, Rat -> true 
  | Pointeur t1, Pointeur t2 -> est_compatible t1 t2
  | Enregistrement l1, Enregistrement l2 -> let (lt1,_) = List.split l1 in
                                            let (lt2,_) = List.split l2 in
                                            List.for_all2 est_compatible lt1 lt2
                                         (*  let l = List.combine lt1 lt2 in
                                            let nl = List.map (fun (a,b) -> est_compatible a b) l in 
                                            not(List.mem false nl) *)
  | TypeNomme (_,t) , _   -> est_compatible t t2
  | _ -> false 

let%test _ = est_compatible Bool Bool
let%test _ = est_compatible Int Int
let%test _ = est_compatible Rat Rat
let%test _ = not (est_compatible Int Bool)
let%test _ = not (est_compatible Bool Int)
let%test _ = not (est_compatible Int Rat)
let%test _ = not (est_compatible Rat Int)
let%test _ = not (est_compatible Bool Rat)
let%test _ = not (est_compatible Rat Bool)
let%test _ = not (est_compatible Undefined Int)
let%test _ = not (est_compatible Int Undefined)
let%test _ = not (est_compatible Rat Undefined)
let%test _ = not (est_compatible Bool Undefined)
let%test _ = not (est_compatible Undefined Int)
let%test _ = not (est_compatible Undefined Rat)
let%test _ = not (est_compatible Undefined Bool)

let est_compatible_list lt1 lt2 =
  try
    List.for_all2 est_compatible lt1 lt2
  with Invalid_argument _ -> false

let%test _ = est_compatible_list [] []
let%test _ = est_compatible_list [Int ; Rat] [Int ; Rat]
let%test _ = est_compatible_list [Bool ; Rat ; Bool] [Bool ; Rat ; Bool]
let%test _ = not (est_compatible_list [Int] [Int ; Rat])
let%test _ = not (est_compatible_list [Int] [Rat ; Int])
let%test _ = not (est_compatible_list [Int ; Rat] [Rat ; Int])
let%test _ = not (est_compatible_list [Bool ; Rat ; Bool] [Bool ; Rat ; Bool ; Int])

let rec getTaille t =
  match t with
  | Int -> 1
  | Bool -> 1
  | Rat -> 2
  | Undefined -> 0
  | Pointeur t1 -> getTaille t1
  | TypeNomme (_,t1) -> getTaille t1
  | Enregistrement l -> let lt = List.map (fun (t1,_) -> getTaille t1) l in
                        let taille = List.fold_right (fun _ q -> 1 + q) lt 0 in
                        taille
  
let%test _ = getTaille Int = 1
let%test _ = getTaille Bool = 1
let%test _ = getTaille Rat = 2
