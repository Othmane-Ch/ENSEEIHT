open Compilateur
open Exceptions




let%test_unit "testEnregistrement1" = 
 try
  let _ = compiler "../../fichiersRat/src-rat-enregistrement-test/testEnregistrement1.rat" in ()
  with
  | IdentifiantNonDeclare("y") -> () 
let%test_unit "testEnregistrement2" = 
  try
    let _ = compiler "../../fichiersRat/src-rat-enregistrement-test/testEnregistrement2.rat" in ()
  with
  | TypeInattendu(_ ,_ )  -> () 

let%test_unit "testEnregistrement3" = 
  let _ = compiler "../../fichiersRat/src-rat-enregistrement-test/testEnregistrement3.rat" in ()

let%test_unit "testEnregistrement4" = 
  let _ = compiler "../../fichiersRat/src-rat-enregistrement-test/testEnregistrement4.rat" in ()

let%test_unit "testEnregistrement5" = 
  let _ = compiler "../../fichiersRat/src-rat-enregistrement-test/testEnregistrement5.rat" in ()