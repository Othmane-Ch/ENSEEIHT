open Compilateur
open Exceptions




let%test_unit "testPointeur1" = 
  let _ = compiler "../../fichiersRat/src-rat-pointeur-test/testPointeur1.rat" in ()

let%test_unit "testPointeur2" = 
  try 
    let _ = compiler "../../fichiersRat/src-rat-pointeur-test/testPointeur2.rat" in ()
  with
  | TypeInattendu(Int, _) -> () 
let%test_unit "testPointeur3" = 
  try 
   let _ = compiler "../../fichiersRat/src-rat-pointeur-test/testPointeur3.rat" in ()
  with
  | TypeInattendu(_,_) -> () 

let%test_unit "testPointeur4" = 
  let _ = compiler "../../fichiersRat/src-rat-pointeur-test/testPointeur4.rat" in ()

