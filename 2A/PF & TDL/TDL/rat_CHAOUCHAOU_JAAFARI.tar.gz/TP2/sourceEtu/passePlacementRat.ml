module PassePlacementRat : Passe.Passe with type t1 = Ast.AstType.programme and type t2 = Ast.AstPlacement.programme =
struct
  open Type
  open Tds
  open Exceptions
  open Ast
  open AstPlacement

  type t1 = Ast.AstType.programme
  type t2 = Ast.AstPlacement.programme






(* analyse_type_instruction : string -> int -> AstType.instruction  -> AstPlacement.instruction *)
(* Paramètre reg : registre *)
(* Paramètre dep : le deplacement *)
(* Paramètre i : l'instruction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'instruction
en une instruction de type AstType.instruction *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_placement_instruction reg dep i =
  match i with
    | AstType.Declaration(ia,e) -> let InfoVar(_,t,_,_) = info_ast_to_info ia in
    let taille = getTaille t in
    modifier_adresse_info dep reg ia;
    (i,taille+dep)
    | AstType.TantQue(e,b) -> let nb = analyse_placement_bloc reg dep b in
    (i,dep)
    | AstType.Conditionnelle(e,bt,be) -> let _ = analyse_placement_bloc "SB" 0 bt in
    let _ = analyse_placement_bloc "SB" 0 be in
    (i,dep)
    | _    -> (i,dep)
and analyse_placement_bloc reg dep li = 
      match li with 
        | []  -> []
        | i::q -> let (ni,ndep) = analyse_placement_instruction reg dep i in
                  ni::(analyse_placement_bloc reg ndep q)
                  
                

let rec analyse_placement_param dep rlp =
    match rlp with
      | [] -> []
      | ia::q -> 
      let InfoVar(_,t,_,_) = info_ast_to_info ia in
      let taille = getTaille t in
      modifier_adresse_info (dep - taille) "LB" ia;    
      ia::(analyse_placement_param (dep-taille) q)

(* analyse_placement_fonction : AstType.fonction -> AstPlacement.fonction *)
let analyse_placement_fonction (AstType.Fonction(ia,lp,b)) =
    let nb = analyse_placement_bloc "LB" 3 b in
    let nlp = analyse_placement_param 0 (List.rev lp) in
    Fonction(ia,nlp,nb)

(* analyser : AstType.Programme -> AstPlacement.Programme *)
let analyser(AstType.Programme(ltd,lf,b)) = 
  let nlf = List.map analyse_placement_fonction lf in
  let nb = analyse_placement_bloc "SB" 0 b in 
  Programme(nlf,nb)

end